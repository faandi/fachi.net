// HangMan
// Andreas Fachathaler 
// 2004-10-XX


using System;

class MainClass
{
	public static void Main(string[] args)
	{
		
		string [] WortListe = {"Hello World", "Donau", "Spiel", "Hangman",		
		"abschätzend", "abwertend", "Adler", "Ähnlichkeit", "Ahnung", "Angelegenheit", "angestrebt", "anrichten", "Anstrengung",
		"anwenden","Art","Ast","Atmen","auffallen","auffordern","aufziehen","aufzäumen","ausbrüten","die Aussprache ",
		"Bach","Bau","Baum","befruchtet","Begebenheit","begegnen","beklauen","bellen","besänftigen","betrügen ","Beute","Bezeichnung",
		"Binnengewässer","Blatt", "bluten","brav","Briefbote", "Brille", "buddeln", "bunt","buschig", 
		"Dach", "dementsprechend", "dicht", "dressieren" , "drohen",  "sich durchringen", 
		"Eichhörnchen","eifrig","erreichen","erregen","erwischen","das Erzeugnis","die Eule","das Euter",
		"fangen","Feld","Fell" ,"Ferkel","Fisch" ,"flattern" ,"fleißig" ,"fliegen" ,"Fohlen","Forderpfote","Forelle","Förster",
		"Frechheit","fressen","freudig", "Frosch","Froschlaich","Fuchs","Futter","füttern",
		"Gestüt", "Gewässer", "Geweih", "gierig", "graben",  "grunzen",
		"Hahn","Hase","Häschen","hauptsächlich","Hecht","heikel","heiser",
		"jagen" ,"Jäger",
		"Kalb","Kater","Katze","Kieme","kläffen","klauen",		
		"Lachs","Lamm","Laubfrosch","lebhaft" ,"locken","Löffel","Laune",
		"Mähne","Maul" ,"Maulwurf","Maulwurfshügel","Maus","Mäusebussard" ,"Mauseloch",
		"Schnabel","schnauben","Schnauze","schüchtern","Schuppe","schnurren","Schritt","Schwalbe",
		"Tatsache","Taube","toben","tollen","traben","trällern",
		"überzogen","Umgebung","Umstand" ,"unaufmerksam" ,"unbeabsichtigt" ,"unleserlich" ,"unscheinbar",
		"verkehrt herum","vermuten","verraten","verrückt","verschlingen" ,"verschlucken","verschmust","verspeisen","Vogel",
		"wiehern","Wiese","winseln","Wurm","Wurst",		
		"zähmen","zärtlich","zerstören","zörgern","zottelig","züchten","zudringlich","Zunge","Zusammenhang","Zustand",
		"zuverlässig","zwitschern"
		};
		
		int WelchesWort = 0;
		Random zufall = new Random ();
		string Wort = "";
		string errateWort = "";
		char rateZeichen;
		bool erraten=false, buchstabenErraten=false;
		short Versuche=0, falschGeraten=0;
			
		
			while (true)
			{
				erraten=false;
				Versuche=0;
				falschGeraten=0;
				
				WelchesWort = zufall.Next(0,WortListe.Length);
				Wort = WortListe[WelchesWort];
					
				// Auffuellen des Erratenen Wortes mit '-' und Spaces
				errateWort = "";
		    	for (int i=0;i<Wort.Length;i++)
			    {
				if (Wort[i]!=' ') errateWort += "-";
				else  errateWort += " ";
			    }
					
				Console.WriteLine("\n\n\n\n\nPseude - HangMan");
			    Console.WriteLine("Das gesuchte Wort hat " + Wort.Length + " Buchstaben");
										
				while (!erraten)
				{
					Console.Write("\nRate einen Buchstaben: ");
					rateZeichen = Convert.ToChar(Console.ReadLine());
					buchstabenErraten=false;	
					Versuche++;
																																										
					for (int index=0;index<Wort.Length;index++)
					{
						if (rateZeichen.ToString().ToLower()[0] == Wort.ToLower()[index])
						{
						errateWort=errateWort.Substring(0,index) + Wort[index] + errateWort.Substring(index+1,errateWort.Length-index-1);
						buchstabenErraten=true;
						}
					}

					if (!buchstabenErraten) falschGeraten++;
					
					
					switch (falschGeraten)
					{
					case 1: Console.Write("\n\n\n\n\n\n\n################"); break;
					case 2: Console.Write("\n             ||");
								 Console.Write("\n             ||");
							     Console.Write("\n             ||");
								 Console.Write("\n             ||");
								 Console.Write("\n             ||");
								 Console.Write("\n             ||");
					             Console.Write("\n################"); break;
					case 3: Console.Write("\n             ||========");
								 Console.Write("\n             ||       ||");
							     Console.Write("\n             ||        O");
								 Console.Write("\n             ||");
								 Console.Write("\n             ||");
								 Console.Write("\n             ||");
					             Console.Write("\n################");break;
					case 4: Console.Write("\n             ||========");
								 Console.Write("\n             ||       ||");
							     Console.Write("\n             ||     \\ O /");
								 Console.Write("\n             ||	      |");
								 Console.Write("\n             ||");
								 Console.Write("\n             ||");
					             Console.Write("\n################"); break;
					case 5: Console.Write("\n             ||========");
								 Console.Write("\n             ||       ||");
							     Console.Write("\n             ||     \\ O /");
								 Console.Write("\n             ||	      |");
								 Console.Write("\n             ||	    /  \\");
								 Console.Write("\n             ||");
					             Console.Write("\n################"); break;
					}		
					
					
					Console.WriteLine("\n\n\n\n Eratenes Wort: " + errateWort);
					if (errateWort == Wort) erraten=true;
					if (falschGeraten > 4) break;		
														
				}
			
		
				if (erraten) Console.WriteLine("\n\nSie haben das Wort eraten!");
				else Console.WriteLine("\n\nSie haben das Wort leider nicht eraten!\nDas Wort war: " + Wort);
				
				Console.WriteLine("\nAnzahl der Versuche: "+ Versuche);
				Console.WriteLine("Anzahl der falsch geratenen Buchstaben: "+ falschGeraten);
				
				Console.Write("\n\nSie können jetzt das Spiel mit 'q' beenden oder mit 'w' weiterspielen!");
				if (Convert.ToChar(Console.ReadLine()) == 'q') break;
							
			}
	}
}